/*
 * MemTest.java
 *
 * ...
 * ...
 * @author Oystein Reigem
 */

package aksis.alignment;

//import javax.management.*;
import java.lang.management.*;
import java.util.*;

public class MemTest {

	/* 2010-10-13. not used. but if used after all, must then be changed in accordance with the other methods here
	public static void print(String pool, String type) {
		// type = "Heap memory" or "Non-heap memory" or ""
		List<MemoryPoolMXBean> pools = ManagementFactory.getMemoryPoolMXBeans();
		for (MemoryPoolMXBean p: pools) {
			if ((pool == "") && (type == "")) {
				System.out.println("Memory pool name=" + p.getName() + " Memory type=" + p.getType() + " Memory usage=" + p.getUsage());
			} else {
				if (   p.getName().startsWith(pool)
				    || type.equals(p.getType().toString())
				   ) {
					//System.out.println(("" + (1000000000 + p.getUsage().getUsed())).substring(1, 10));
					System.out.println(
						  "used "  + ("" + (1000000000 + p.getUsage().getUsed())).substring(1, 10)
						+ " "
						+ ", max " + ("" + (1000000000 + p.getUsage().getMax())).substring(1, 10)
					);
				}
			}
		}
	}
	*/

	// 2006-10-03

	// returns remaining heap space (??????????) in bytes

	public static long getRemainingHeap() {
		/*
		List<MemoryPoolMXBean> pools = ManagementFactory.getMemoryPoolMXBeans();
		long remaining = 0;   // 2010-10-13
		for (MemoryPoolMXBean p: pools) {
			//if (p.getType().toString().equals("Heap memory")) {
			//if (p.getName().startsWith("Tenured Gen")) {
			// 2010-10-13. how test for old generation heap?
				//System.out.println("max " + p.getUsage().getMax());
				//System.out.println("used " + p.getUsage().getUsed());
				//return p.getUsage().getMax() - p.getUsage().getUsed();
				remaining += p.getUsage().getMax() - p.getUsage().getUsed();   // 2010-10-13
				//return Runtime.getRuntime().freeMemory();   // 2010-10-13. ???
			//}
		}
		//// ### error
		//return -1;
		return remaining;
		*/
		// 2010-10-13
		// from <http://www.roseindia.net/javatutorials/OutOfMemoryError_Warning_System.shtml>
		long maxMemory = tenuredGenPool.getUsage().getMax();
		long usedMemory = tenuredGenPool.getUsage().getUsed();

		return maxMemory - usedMemory;
		// end 2010-10-13
	}

	// 2010-10-13
	/*
	public static long[] getMemoryUsage() {
		//System.out.println("MemTest sin getMemoryUsage()");
		List<MemoryPoolMXBean> pools = ManagementFactory.getMemoryPoolMXBeans();
		for (MemoryPoolMXBean p: pools) {
			if (p.getName().startsWith("Tenured Gen")) {
				long[] array = new long[2];
				array[0] = p.getUsage().getMax();
				//System.out.println(array[0]);
				array[1] = p.getUsage().getUsed();
				//System.out.println(array[1]);
				return array;
			}
		}
		// ### error
		return null;
	}
	*/
	public static long[] getMemoryUsage() {
		//System.out.println("MemTest sin getMemoryUsage()");
		// 2010-08-30
		long[] array = new long[2];
		// set default values in case the code below
		// fails to find information about memory use.
		// such failure has been observed on newer platforms.
		// ###at failure now the user will be told that usage is 0 out of max 0,
		// which of course is somewhat misleading...
		array[0] = 0;
		array[1] = 0;
		// end 2010-08-30

		// 2010-10-13
		long maxMemory = tenuredGenPool.getUsage().getMax();
		//System.out.println("maxMemory = " + maxMemory);
		long usedMemory = tenuredGenPool.getUsage().getUsed();
		//System.out.println("usedMemory = " + usedMemory);
		array[0] = maxMemory;
		array[1] = usedMemory;
		// end 2010-10-13

		/*
		List<MemoryPoolMXBean> pools = ManagementFactory.getMemoryPoolMXBeans();
		for (MemoryPoolMXBean p: pools) {
			System.out.println("pool: " + p.getName());
			//if (p.getName().startsWith("Tenured Gen")) {   // 2010-10-13. doesn't work any more
			//if (p.getType() == MemoryType.HEAP && p.isUsageThresholdSupported()) {   // neither this
				//long[] array = new long[2];   // 2010-08-30
				array[0] += p.getUsage().getMax();
				//System.out.println(array[0]);
				array[1] += p.getUsage().getUsed();
				//System.out.println(array[1]);
				return array;
			//}
		}
		*/



		/* not?
		perhaps this is for memory in general, not for this particular program
		array[0] = Runtime.getRuntime().totalMemory();
		array[1] = array[0] - Runtime.getRuntime().freeMemory();
		//array[1] = Runtime.getRuntime().totalMemory();
		*/

		/* where is SystemInformation?
		perhaps not what we're looking for anyway.
		perhaps this is for memory in general, not for this particular program
		long memorySize = SystemInformation.getMemoryUsage();
		long residentSize = SystemInformation.getMemoryResident();
		long freemem = SystemInformation.getFreeMem()/1024;
		long maxmem = SystemInformation.getMaxMem()/1024;
		*/

		// ### error
		//return null;
		return array;   // 2010-08-30
	}
	// end 2010-10-13
	// end 2006-10-03

	// 2010-10-13
	// from <http://www.roseindia.net/javatutorials/OutOfMemoryError_Warning_System.shtml>
	private static final MemoryPoolMXBean tenuredGenPool = findTenuredGenPool();
	/**
	 * Tenured Space Pool can be determined by it being of type
	 * HEAP and by it being possible to set the usage threshold.
	 */
	private static MemoryPoolMXBean findTenuredGenPool() {
		for (MemoryPoolMXBean pool : ManagementFactory.getMemoryPoolMXBeans()) {
			// I don't know whether this approach is better, or whether
			// we should rather check for the pool name "Tenured Gen"?
			if (pool.getType() == MemoryType.HEAP && pool.isUsageThresholdSupported()) {
				return pool;
			}
		}
		throw new AssertionError("Could not find tenured space");
	}
	// end 2010-10-13

}
