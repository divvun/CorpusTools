/*
 * AnchorWordHits.java
 *
 * ...
 * ...
 * ...
 */

package aksis.alignment;

// ��� ikke sjekket n�yaktig hva vi trenger
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.lang.String;
import java.io.*;
//import aksis.awt2.AwtUtil;

// ...

class AnchorWordHit {

	Integer index;   // refers to entry in anchor word list
	int elementNumber;   // element number   // 2006-04-05
	int pos;   // position of word within its element. 2006-04-04. 2006-04-05 or several elements! ###
	String word;   // word as written in the text

	public AnchorWordHit(Integer index, int elementNumber, int pos, String word) {   // 2006-04-04, 2006-04-05
		this.index = index;
		this.elementNumber = elementNumber;   // 2006-04-05
		this.pos = pos;   // 2006-04-04
		this.word = word;
	}

	public Integer getIndex() {
		return index;
	}

	public String getWord() {
		return word;
	}

	// 2006-04-04
	public int getPos() {
		return pos;
	}

	// 2006-04-05
	public Integer getElementNumber() {
		return elementNumber;
	}

	// 2006-04-05
	public void setPos(int pos) {
		this.pos = pos;
	}

	// ### for debugging
	public String toString() {
		return "(index=" + index.intValue() + ";pos=" + pos + ";word=" + word + ")";
	}

}

class AnchorWordHits {

	java.util.List hits;

	public AnchorWordHits () {
		hits = new ArrayList();
	}

	public void add(AnchorWordHit hit) {
		hits.add(hit);
	}

	// ### for debugging
	public String toString() {
		Iterator it = hits.iterator();
		StringBuffer ret = new StringBuffer();
		ret.append("[");
		while (it.hasNext()) {
			if (ret.equals("[")) { ret.append(","); }
			ret.append((AnchorWordHit)it.next());
		}
		return new String(ret);
	}

}

