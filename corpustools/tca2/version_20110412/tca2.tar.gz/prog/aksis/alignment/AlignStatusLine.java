/*
 * AlignStatusLine.java
 *
 * ...
 * ...
 * ...
 */

package aksis.alignment;

import java.awt.*;
import javax.swing.*;

class AlignStatusLine extends JPanel {

	public final static int PROGRESS_MIN = 0;
	public final static int PROGRESS_MAX = 100;
	public final static int MEMORY_USAGE_MIN = 0;   // 2006-10-03
	public final static int MEMORY_USAGE_MAX = 100;   // 2006-10-03

	private JTextField text;   // (private 2006-10-03)
	private JTextField counter;   // (private 2006-10-03)
	private JProgressBar progress;   // (private 2006-10-03)
	//protected JProgressBar memoryUsage;   // 2006-10-03
	private JTextField memoryUsage;   // 2006-10-03

	public AlignStatusLine() {

		super(new BorderLayout());

		//text = new JTextField(10);
		text = new JTextField(20);
		counter = new JTextField(10);   // ### not used

		UIManager.put("ProgressBar.selectionBackground", Color.black);
		UIManager.put("ProgressBar.selectionForeground", Color.white);
		UIManager.put("ProgressBar.foreground", Color.blue);
		UIManager.put("ProgressBar.cellLength", new Integer(5));
		UIManager.put("ProgressBar.cellSpacing", new Integer(1));
		progress = new JProgressBar();

		progress.setMinimum(PROGRESS_MIN);
		progress.setMaximum(PROGRESS_MAX);
		progress.setStringPainted(true);

		// 2006-10-03
		// ###dette g�r dessverre ikke. f�r ikke til to ulike progress bars.
		// se <http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4226498>
		//UIManager.put("ProgressBar.selectionBackground", Color.black);
		//UIManager.put("ProgressBar.selectionForeground", Color.white);
		//UIManager.put("ProgressBar.foreground", Color.red);
		//UIManager.put("ProgressBar.background", Color.green);   ???
		//UIManager.put("ProgressBar.cellLength", new Integer(5));
		//UIManager.put("ProgressBar.cellSpacing", new Integer(1));
		//memoryUsage = new JProgressBar();
		memoryUsage = new JTextField(5);

		//memoryUsage.setMinimum(MEMORY_USAGE_MIN);
		//memoryUsage.setMaximum(MEMORY_USAGE_MAX);
		//memoryUsage.setStringPainted(true);

		Box b = new Box(BoxLayout.X_AXIS);
		b.add(progress);
		b.add(new JLabel("  Memory usage: "));
		b.add(memoryUsage);
		// end 2006-10-03

		add(BorderLayout.WEST, text);
		add(BorderLayout.CENTER, counter);
		//add(BorderLayout.EAST, progress);
		add(BorderLayout.EAST, b);   // 2006-10-03

		//clearProgress();
		////setMemoryUsage();   // 2006-10-03
		//clearMemoryUsage();   // 2006-10-03
		clear();   // 2006-10-03

	}

	void setText(String s) {
		//System.out.println("AlignStatusLine setText method. s=" + s);
		text.setText(s);
		//repaint_();   // 2006-10-03
		Rectangle rect = text.getBounds();   // 2006-10-03
		rect.x = 0;   // 2006-10-03
		rect.y = 0;   // 2006-10-03
		text.paintImmediately(rect);   // 2006-10-03
	}

	void clearText() {
		setText("");
		//repaint_();   // 2006-10-03
	}

	void setCounter(int c) {
		//System.out.println("AlignStatusLine setCounter method. c=" + c);
		counter.setText(Integer.toString(c));
		//repaint_();   // 2006-10-03
		Rectangle rect = counter.getBounds();   // 2006-10-03
		rect.x = 0;   // 2006-10-03
		rect.y = 0;   // 2006-10-03
		counter.paintImmediately(rect);   // 2006-10-03
	}

	void clearCounter() {
		counter.setText("");
		//repaint_();   // 2006-10-03
		Rectangle rect = counter.getBounds();   // 2006-10-03
		rect.x = 0;   // 2006-10-03
		rect.y = 0;   // 2006-10-03
		counter.paintImmediately(rect);   // 2006-10-03
		}

	void setProgress(int p) {
		//System.out.println("AlignStatusLine setProgress method. p=" + p);
		progress.setVisible(true);
		progress.setValue(p);
		//repaint_();   // 2006-10-03
		Rectangle rect = progress.getBounds();   // 2006-10-03
		rect.x = 0;   // 2006-10-03
		rect.y = 0;   // 2006-10-03
		progress.paintImmediately(rect);   // 2006-10-03
	}

	void clearProgress() {
		progress.setVisible(false);
		//repaint_();   // 2006-10-03
		Rectangle rect = progress.getBounds();   // 2006-10-03
		rect.x = 0;   // 2006-10-03
		rect.y = 0;   // 2006-10-03
		progress.paintImmediately(rect);   // 2006-10-03
	}

	// 2006-10-03
	void setMemoryUsage() {
		//System.out.println("AlignStatusLine sin setMemoryUsage()");
		long[] array = MemTest.getMemoryUsage();
		long max  = array[0];
		long used = array[1];
		int percentUsed = Math.round((float)((float)(used) / max * 100.0));
		System.out.println("Memory used = " + percentUsed + "%");
		//memoryUsage.setValue(percentUsed);
		memoryUsage.setText("" + percentUsed + "%");
		//repaint_();
		//memoryUsage.paintImmediately(memoryUsage.getBounds());
		// ###hadde forferdelige problemer med � f� frisket opp memoryUsage,
		// og det som manglet var x, y = 0, 0
		Rectangle rect = memoryUsage.getBounds();
		rect.x = 0;
		rect.y = 0;
		memoryUsage.paintImmediately( rect );
	}

	void clearMemoryUsage() {
		memoryUsage.setText("");
		Rectangle rect = memoryUsage.getBounds();
		rect.x = 0;
		rect.y = 0;
		memoryUsage.paintImmediately( rect );
	}
	// end 2006-10-03

	void clear() {
		clearText();
		clearCounter();
		clearProgress();
		setMemoryUsage();   // 2006-10-03
	}

	/*
	void repaint_() {
		// ��������������������� funker ikke. havner bakerst i k�en?
		//text.repaint();
		//counter.repaint();
		//progress.repaint();
		//
		text.paintImmediately(text.getBounds());   // 2006-10-03
		counter.paintImmediately(counter.getBounds());   // 2006-10-03
		progress.paintImmediately(progress.getBounds());   // 2006-10-03
		memoryUsage.paintImmediately(memoryUsage.getBounds());   // 2006-10-03
	}
	*/

}


