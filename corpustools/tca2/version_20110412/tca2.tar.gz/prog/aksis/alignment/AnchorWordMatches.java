/*
 * AnchorWordMatches.java
 *
 * ...
 * ...
 * @author Oystein Reigem
 */

package aksis.alignment;

import java.util.*;

/**
 * information about one single anchor word match
 */
class AnchorWordMatch {

	Integer index;   // refers to entry in anchor word list, numbered from 0 and upwards
	String[] words;    // the matching words from the texts

	AnchorWordMatch(Integer i, String[] ws) {
		index = i;
		words = ws;
	}

	public Integer getIndex() {
		return index;
	}

	public String[] getWords() {
		return words;
	}

	// ### for debugging (?)
	public String toString() {

		StringBuffer ret = new StringBuffer();
		// ��� blir ikke denne metoden brukt???????????????????????
		ret.append((index.intValue() + 1) + " ");   // +1 since we want anchor word entries numbered from 1 and upwards when they are displayed
		for (int i = 0; i > words.length; i++) {
			if (i > 0) { ret.append("/"); }
			ret.append(words[i]);
		}

		return new String(ret);

	}

}

/**
 * information about all the anchor word matches
 * for the elements under alignment -
 * a list of all the single matches
 */
class AnchorWordMatches {

	java.util.List matches;

	AnchorWordMatches() {

		matches = new ArrayList();

	}

	public void add(AnchorWordMatch match) {

		matches.add(match);

	}

	// ### for debugging (?)
	public String toString() {

		Iterator it = matches.iterator();
		StringBuffer ret = new StringBuffer();
		ret.append("[");
		boolean first = true;
		while (it.hasNext()) {
			if (true) {
				ret.append(",");
				first = false;
			}
			ret.append(((AnchorWordMatch)it.next()).toString());
		}
		ret.append("]");

		return new String(ret);

	}

}

/**
 * AnchorWordMatchInfo are elements in the list AnchorWordMatches.
 * each AnchorWordMatchInfo contains info about a token pair.
 * e,g, there is only one element for "car - bil"
 * even if the tokens "car" and "bil" occur more than once.
 * e,g, there are separate elements for "car - bil" and "car - bilen".
 * AnchorWordMatchInfo contains both the tokens and a count of occurrences of the token pair
 */
/*
class AnchorWordMatchInfo {

	protected Integer anchorWordEntryNumber;
	protected String[] words;
	protected int count;

	AnchorWordMatchInfo(Integer anchorWordEntryNumber, String[] words) {
		AnchorWordMatchInfo.this.anchorWordEntryNumber = anchorWordEntryNumber;
		AnchorWordMatchInfo.this.words = new String[Alignment.NUM_FILES];
		for (int t=0; t<Alignment.NUM_FILES; t++) {
			AnchorWordMatchInfo.this.words[t] = words[t];
		}
		AnchorWordMatchInfo.this.count = 1;
	}

	public String toString() {

		StringBuffer str = new StringBuffer();
		str.append("" + anchorWordEntryNumber + " ");
		for (int t=0; t<Alignment.NUM_FILES; t++) {
			if (t > 0) {
				str.append("/");
			}
			str.append(words[t]);
		}
		if (count > 1) {
			str.append(" (" + count + ")");
		}
		return new String(str);

	}

	public boolean sameTokens(AnchorWordMatchInfo otherAnchorWordMatchInfo) {

		for (int t=0; t<Alignment.NUM_FILES; t++) {
			if (!words[t].equals(otherAnchorWordMatchInfo.words[t])) {
				return false;
			}
		}
		return true;

	}

	public void incrementCount() {

		count++;

	}

}
*/

/**
 * AnchorWordMatches is a list with info about
 * all the anchor word matches
 * in the currently aligned elements.
 * ### lages kun helt til slutt ved en suggest.
 * ikke ved unalign, more, less.
 * the list is displayed in the gui.
 * each element in the list is an AnchorWordMatchInfo.
 */
/*
class AnchorWordMatches {

	//protected List list = new ArrayList();
	protected DefaultListModel list;

	AnchorWordMatches() {

		list = new DefaultListModel();

	}

	public void add(AnchorWordMatchInfo newElement) {

		//System.out.println("add(" + newElement + ")");

		for (Enumeration enum = list.elements(); enum.hasMoreElements();) {
			// next info
			AnchorWordMatchInfo element = (AnchorWordMatchInfo)enum.nextElement();
			if (element.sameTokens(newElement)) {
				element.incrementCount();
				return;
			}
		}
		list.addElement(newElement);
		return;

	}

	public boolean empty() {

		return (list.getSize() == 0);

	}

	public void compute(AlignmentModel model) {

		//System.out.println("compute()");
		clear();
		if (model.toAlign.elements[0].getSize() > 0 && model.toAlign.elements[1].getSize() > 0) {
			int e1, e2;
			for (Enumeration enum1 = model.toAlign.elements[0].elements(); enum1.hasMoreElements();) {
				e1 = ((AElement)enum1.nextElement()).elementNumber;
				System.out.println("e1=" + e1);
				ElementInfo el1 = model.compare.elementsInfo[0].getElementInfo(model, e1, 0);
				System.out.println("el1=" + el1);
				Iterator eit1 = el1.anchorWordHits.hits.iterator();
				while (eit1.hasNext()) {
					AnchorWordHit l1 = (AnchorWordHit)eit1.next();
					Integer anchorWordEntryNumber1 = l1.getIndex();
					//System.out.println("anchorWordEntryNumber1=" + anchorWordEntryNumber1);
					String word1 = l1.getWord();
					//System.out.println("word1=" + word1);
					for (Enumeration enum2 = model.toAlign.elements[1].elements(); enum2.hasMoreElements();) {
						e2 = ((AElement)enum2.nextElement()).elementNumber;
						System.out.println("e2=" + e2);
						ElementInfo el2 = model.compare.elementsInfo[1].getElementInfo(model, e2, 1);
						System.out.println("el2=" + el2);
						Iterator eit2 = el2.anchorWordHits.hits.iterator();
						while (eit2.hasNext()) {
							AnchorWordHit l2 = (AnchorWordHit)eit2.next();
							Integer anchorWordEntryNumber2 = l2.getIndex();
							//System.out.println("anchorWordEntryNumber2=" + anchorWordEntryNumber2);
							String word2 = l2.getWord();
							//System.out.println("word2=" + word2);
							//System.out.println("anchorWordEntryNumber1=" + anchorWordEntryNumber1 + " word1=" + word1 + " anchorWordEntryNumber2=" + anchorWordEntryNumber2 + " word2=" + word2);
							if (anchorWordEntryNumber1.equals(anchorWordEntryNumber2)) {
								String[] words = new String[Alignment.NUM_FILES];
								words[0] = word1;
								words[1] = word2;
								AnchorWordMatchInfo newAnchorWordMatchInfo = new AnchorWordMatchInfo(anchorWordEntryNumber1, words);
								AnchorWordMatches.this.add(newAnchorWordMatchInfo);
							}
						}
					}
				}
			}
			// ######### hadde v�rt fint med melding "no anchor word matches",
			// men hvordan skal jeg gj�re det uten � trikse det til?
			// (meldingen skal bare komme n�r det st�r minst ett element p� hver side i toAlign)
			//if (AnchorWordMatches.empty()) {
			//	...
			//}
		}

	}

	public void clear() {

		list.clear();

	}

}
*/

