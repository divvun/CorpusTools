import java.awt.*;
import java.net.*;
import javax.swing.*;

public class ImagesExample {
    public static void main(String[] args) throws MalformedURLException {
        JPanel cp = new JPanel(new GridLayout(0,3));
        addImage(cp, "http://today.java.net/jag/bio/JagHeadshot-small.jpg");
        addImage(cp, "http://today.java.net/jag/Image95-small.jpeg");
        addImage(cp, "http://today.java.net/jag/Image69-small.jpeg");
        addImage(cp, "http://today.java.net/jag/Image56-small.jpeg");
        addImage(cp, "http://today.java.net/jag/Image25-small.jpeg");
        addImage(cp, "http://today.java.net/jag/Image24-small.jpeg");

        JFrame f = new JFrame("ImagesExample");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setContentPane(cp);
        f.pack();
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }

    static void addImage(JPanel cp, String url) throws MalformedURLException {
        cp.add(new JLabel(new ImageIcon(new URL(url))));
    }
}

