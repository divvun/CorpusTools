				���String retLine;   // to contain one line of info
							getIndex()
							getWord()
							getPos()
						// look through all texts and find the highest/lowest number of hits in any text.
						// this highest/lowest number might be the contribution to the anchor word score
						// for this anchor word list entry,
						// provided the hit is in every text..
						// example:
						// anchor word entry: "xxx/yyy,yy"
						// texts: "I saw a xxx going down the xxx" vs "Jeg s� en yyy nede i yy yyy"
						// (���������idiotisk, ubrukelig eksempel)
						// 2 hits in first text and 3 hits in second text makes a score of max(2,3) = 3
				int high = 0;
				int highSum = 0;
				int low = 0;
				int lowSum = 0;
				int oneSum = 0;
							if (presentInAllTexts) {
								if (t == 0) {
									// ��� hvorfor brukes ikke toString-metode? duplisert programmering
									���retLine += INDENT + INDENT + (smallest + 1) + " ";   // +1 since we want anchor word entries numbered from 1 and upwards when they are displayed
								} else {
									���retLine += "/";
								}
							}
										// samle opp ordet i en ### liste for text t, s�sant det er et nytt ord
										if (first) {
											first = false;
										} else {
											if (presentInAllTexts) {
												���retLine += ",";
											}
										}
										if (presentInAllTexts) {
											���retLine += hit.getWord();
										}
							if (count > high) { high = count; }
							if (count < low) { low = count; }
						if (presentInAllTexts) {
							if (model.getClusterScoreMethod() == 3) {
								���retLine += " (" + high + " points)";
							} if (model.getClusterScoreMethod() == 2) {
								���retLine += " (" + low + " points)";
							} else { // if (model.getClusterScoreMethod() == 1)
								���retLine += " (" + 1 + " points)";   // ��� sl�yfe?
							}
							���ret.add(retLine);
						}
					// add points for this anchor word list entry
					if (presentInAllTexts) {
						highSum += high;
						lowSum += low;
						oneSum += 1;
					}
				// ...
				if (model.getClusterScoreMethod() == 3) {
					anchorWordScore = highSum;
				} if (model.getClusterScoreMethod() == 2) {
					anchorWordScore = lowSum;
				} else { // if (model.getClusterScoreMethod() == 1)
					anchorWordScore = oneSum;
				}

				if (anchorWordScore > 0) {
					retLine = INDENT + "Anchor word score: " + anchorWordScore;
				} else {
					retLine = INDENT + "No anchor word matches. Score: 0";
				}
				// ...is header for anchor info. insert at top
				ret.add(0, retLine);

